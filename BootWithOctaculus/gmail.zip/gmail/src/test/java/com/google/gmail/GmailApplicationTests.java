package com.google.gmail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
