package com.training.voting.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.voting.entity.GoVoters;

@RestController
@RequestMapping("/api/voting")
public class HelloRestController {
	// http://localhost:9090/api/voting/hello
	@GetMapping("/hello")
	public String sayHello() {
		return "Hello to Springboot Rest API";
	}

	@GetMapping("/names") // Rest End Point
	public List<String> displayNames() {

		List<String> names = Arrays.asList("Aman", "Rohal", "Kamal", "Suresh");
		return names;
	}

	@GetMapping("/voter")
	public GoVoters goVoters() {
		return new GoVoters("Ram", 23, "Mr Shyam", "Male", 912312346789L, "ram@gmail.com", 8901236789L);
	}

	@GetMapping("/list")
	public List<GoVoters> getList() {
		List<GoVoters> list = new ArrayList<>();
		list.add(new GoVoters("Ram", 23, "Mr Shyam", "Male", 912312346789L, "ram@gmail.com", 8901236789L));
		list.add(new GoVoters("Kiram", 25, "Mr Mohan", "Female", 909012346789L, "kiran@gmail.com", 8909236789L));
		return list;
	}

}
