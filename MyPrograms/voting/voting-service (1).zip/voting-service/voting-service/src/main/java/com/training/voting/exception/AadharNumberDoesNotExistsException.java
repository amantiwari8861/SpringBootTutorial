package com.training.voting.exception;

public class AadharNumberDoesNotExistsException extends RuntimeException {

	public AadharNumberDoesNotExistsException() {}

	public AadharNumberDoesNotExistsException(String message) {
		super(message);
	}

}
